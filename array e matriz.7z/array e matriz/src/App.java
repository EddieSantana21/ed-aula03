import java.util.Arrays;

public class App {
    public static void main(String[] args) throws Exception {
        // Declaração do vetor de inteiros com tamanho 5
        int[] meu_array = new int [5];

        // Inicialização do vetor
        meu_array[0] = 10;
        meu_array[1] = 20;
        meu_array[2] = 30;
        meu_array[3] = 40;
        meu_array[4] = 50;

        int elemnt0 = meu_array[0];
        int elemnt1 = meu_array[1];
        int elemnt2 = meu_array[2];
        int elemnt3 = meu_array[3];
        int elemnt4 = meu_array[4];

        System.out.println(elemnt0);
        System.out.println(elemnt1);
        System.out.println(elemnt2);
        System.out.println(elemnt3);
        System.out.println(elemnt4);

        for (int i = 0; i < meu_array.length; i++){
            System.out.println("Elemento " + i + ": "+ meu_array[i]);
        }

        String[] lista_aluno = new String[5];
        lista_aluno[0]="Eddie Santana";
        lista_aluno[0]="Davi Nunes";
        lista_aluno[0]="Well Rodrigues";
        lista_aluno[0]="Ramon Dino";
        lista_aluno[0]="Mel Maia";

        String[] lista_cidades = {"Poá","Ferraz","Itu"};
        for (int i = 0; i < lista_cidades.length; i++) {
            System.out.println("Elemento "+i+ ": "+ lista_cidades[i]);
        }

        int[] array_vazia = new int[5];
        Arrays.fill(array_vazia, 10);

        System.out.println("" + Arrays.toString(array_vazia));

        boolean resp = Arrays.equals(lista_cidades, lista_cidades);
        System.out.println(resp);

    }
}
